from __future__ import annotations
import re
from datetime import datetime
from pathlib import Path
from typing import Any
import httpx
from storage.models import (
    Alert, ContributorBaseline, DetectionResult,
    NormalizedEvent, RepoScanResult, Severity,
)

BINARY_EXTS = {".exe", ".o", ".so", ".dll", ".bin", ".wasm", ".pyc", ".a", ".lib", ".out"}
CI_PATTERNS = [".github/workflows/", ".gitlab-ci.yml", "Jenkinsfile", ".circleci/", "Makefile"]
GITHUB_API = "https://api.github.com"


def parse_repo_url(url: str) -> tuple[str, str]:
    """Extract owner and repo name from any GitHub URL format."""
    url = url.strip().rstrip("/")
    patterns = [
        r"github\.com[/:]([^/]+)/([^/\s\.]+)",
        r"^([^/]+)/([^/]+)$",
    ]
    for pat in patterns:
        m = re.search(pat, url)
        if m:
            owner, repo = m.group(1), m.group(2)
            repo = repo.replace(".git", "")
            return owner, repo
    raise ValueError(f"Cannot parse GitHub URL: {url}")


class GitHubRepoScanner:
    """
    Scans any public GitHub repo using the GitHub public API.
    No API key needed for public repos (60 req/hour unauthenticated).
    """

    def __init__(self, github_token: str | None = None):
        headers = {"Accept": "application/vnd.github.v3+json", "User-Agent": "GitSentinel/1.0"}
        if github_token:
            headers["Authorization"] = f"token {github_token}"
        self.client = httpx.AsyncClient(headers=headers, timeout=15.0)

    async def scan(self, repo_url: str) -> RepoScanResult:
        owner, repo = parse_repo_url(repo_url)
        repo_id = f"{owner}/{repo}"

        repo_info = await self._get_repo_info(owner, repo)
        commits = await self._get_recent_commits(owner, repo, limit=30)
        contributors = await self._get_contributors(owner, repo)

        alerts: list[Alert] = []
        contributor_commit_counts: dict[str, int] = {}
        for c in contributors:
            contributor_commit_counts[c.get("login", "unknown")] = c.get("contributions", 0)

        all_findings: list[DetectionResult] = []

        # --- Check 1: New contributors with sudden high activity ---
        for contributor in contributors:
            login = contributor.get("login", "unknown")
            count = contributor.get("contributions", 0)
            if count <= 3 and len(contributors) > 5:
                finding = DetectionResult(
                    severity=Severity.MEDIUM,
                    detector_name="NewContributorDetector",
                    reason=f"'{login}' has only {count} commit(s) but is listed as a contributor.",
                    recommendation="Review their commits manually to ensure they are legitimate.",
                    confidence=0.7,
                )
                all_findings.append(finding)

        # --- Check 2: Binary files in recent commits ---
        binary_found = []
        ci_modified_by_new = []

        for commit in commits[:15]:
            sha = commit.get("sha", "")
            author = commit.get("commit", {}).get("author", {}).get("name", "unknown")
            author_commits = contributor_commit_counts.get(author, 0)

            detail = await self._get_commit_detail(owner, repo, sha)
            files = detail.get("files", [])
            filenames = [f.get("filename", "") for f in files]

            for fname in filenames:
                ext = Path(fname).suffix.lower()
                if ext in BINARY_EXTS:
                    binary_found.append((fname, author))

            ci_files = [f for f in filenames if any(p in f for p in CI_PATTERNS)]
            if ci_files and author_commits < 10:
                ci_modified_by_new.append((ci_files, author, author_commits))

        if binary_found:
            for fname, author in binary_found[:3]:
                finding = DetectionResult(
                    severity=Severity.CRITICAL,
                    detector_name="BinaryBlobDetector",
                    reason=f"Binary file found in recent commits: '{fname}' by '{author}'",
                    recommendation="Run `file <binary>` to inspect. Verify source code exists. This is a major supply chain attack indicator.",
                    confidence=0.95,
                )
                all_findings.append(finding)

        if ci_modified_by_new:
            for ci_files, author, count in ci_modified_by_new[:2]:
                finding = DetectionResult(
                    severity=Severity.HIGH,
                    detector_name="CIFileDetector",
                    reason=f"CI/CD file(s) {ci_files} modified by '{author}' who only has {count} total commits.",
                    recommendation="Review CI changes carefully for added external scripts, curl commands, or secrets exfiltration.",
                    confidence=0.85,
                )
                all_findings.append(finding)

        # --- Check 3: Contributor dominance (one person dominates commits) ---
        if contributors and len(contributors) >= 3:
            top = contributors[0]
            top_pct = top.get("contributions", 0) / max(sum(c.get("contributions", 0) for c in contributors), 1)
            if top_pct > 0.85:
                finding = DetectionResult(
                    severity=Severity.LOW,
                    detector_name="ContributorDominanceDetector",
                    reason=f"'{top.get('login')}' made {top_pct*100:.0f}% of all commits. Single point of trust failure.",
                    recommendation="Encourage more distributed maintainership. A single compromised account = full repo compromise.",
                    confidence=0.8,
                )
                all_findings.append(finding)

        # --- Check 4: Repo has no security policy ---
        has_security = await self._check_file_exists(owner, repo, "SECURITY.md")
        if not has_security:
            finding = DetectionResult(
                severity=Severity.LOW,
                detector_name="SecurityPolicyDetector",
                reason="Repository has no SECURITY.md — no vulnerability disclosure process defined.",
                recommendation="Add a SECURITY.md with a responsible disclosure policy.",
                confidence=1.0,
            )
            all_findings.append(finding)

        # --- Compute overall risk ---
        if all_findings:
            sev_order = [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW]
            top_sev = Severity.NONE
            for s in sev_order:
                if any(f.severity == s for f in all_findings):
                    top_sev = s
                    break

            risk_score = min(100, sum(f.severity.score() for f in all_findings))

            alert = Alert(
                repo_id=repo_id,
                actor="scan",
                risk_score=risk_score,
                severity=top_sev,
                findings=all_findings,
                timestamp=datetime.utcnow(),
            )
            alerts.append(alert)
        else:
            risk_score = 0
            top_sev = Severity.NONE

        return RepoScanResult(
            repo_url=f"https://github.com/{owner}/{repo}",
            repo_id=repo_id,
            overall_risk=risk_score,
            overall_severity=top_sev,
            total_commits_scanned=len(commits),
            contributors_count=len(contributors),
            alerts=alerts,
            stars=repo_info.get("stargazers_count", 0),
            description=repo_info.get("description", "") or "",
        )

    async def _get_repo_info(self, owner: str, repo: str) -> dict:
        try:
            r = await self.client.get(f"{GITHUB_API}/repos/{owner}/{repo}")
            return r.json() if r.status_code == 200 else {}
        except Exception:
            return {}

    async def _get_recent_commits(self, owner: str, repo: str, limit: int = 30) -> list[dict]:
        try:
            r = await self.client.get(f"{GITHUB_API}/repos/{owner}/{repo}/commits?per_page={limit}")
            return r.json() if r.status_code == 200 else []
        except Exception:
            return []

    async def _get_contributors(self, owner: str, repo: str) -> list[dict]:
        try:
            r = await self.client.get(f"{GITHUB_API}/repos/{owner}/{repo}/contributors?per_page=30")
            return r.json() if r.status_code == 200 and isinstance(r.json(), list) else []
        except Exception:
            return []

    async def _get_commit_detail(self, owner: str, repo: str, sha: str) -> dict:
        try:
            r = await self.client.get(f"{GITHUB_API}/repos/{owner}/{repo}/commits/{sha}")
            return r.json() if r.status_code == 200 else {}
        except Exception:
            return {}

    async def _check_file_exists(self, owner: str, repo: str, filename: str) -> bool:
        try:
            r = await self.client.get(f"{GITHUB_API}/repos/{owner}/{repo}/contents/{filename}")
            return r.status_code == 200
        except Exception:
            return False

    async def close(self) -> None:
        await self.client.aclose()
