from __future__ import annotations
import asyncio
import logging
import os
from contextlib import asynccontextmanager
from datetime import datetime

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, HTMLResponse
from pydantic import BaseModel

from ingestion.scanner import GitHubRepoScanner
from storage.database import Database
from storage.models import Severity

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("gitsentinel")

db: Database
scanner: GitHubRepoScanner


@asynccontextmanager
async def lifespan(app: FastAPI):
    global db, scanner
    db = Database()
    scanner = GitHubRepoScanner(github_token=os.getenv("GITHUB_TOKEN"))
    log.info("GitSentinel v2 started — API ready")
    yield
    await scanner.close()
    db.close()
    log.info("GitSentinel stopped")


app = FastAPI(
    title="GitSentinel",
    description="Open source supply chain security monitor",
    version="2.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(Exception)
async def global_handler(request: Request, exc: Exception):
    log.error("Unhandled: %s", exc, exc_info=True)
    return JSONResponse(status_code=500, content={"error": str(exc)})


# ── Health ──────────────────────────────────────────────────────────────────

@app.get("/health")
async def health():
    return {"status": "ok", "version": "2.0.0"}


# ── Stats for dashboard header cards ────────────────────────────────────────

@app.get("/api/stats")
async def get_stats():
    return db.get_stats()


# ── Core feature: scan any GitHub repo ──────────────────────────────────────

class ScanRequest(BaseModel):
    repo_url: str


@app.post("/api/scan")
async def scan_repo(req: ScanRequest):
    """
    Scan any public GitHub repository for supply chain attack indicators.
    This is the main demo feature — paste any GitHub URL and get real results.
    """
    url = req.repo_url.strip()
    if not url:
        raise HTTPException(status_code=400, detail="repo_url is required")

    log.info("Scanning repo: %s", url)
    try:
        result = await scanner.scan(url)
        db.save_scan(result)
        for alert in result.alerts:
            db.insert_alert(alert)
        log.info("Scan complete: %s | risk=%d severity=%s",
                 result.repo_id, result.overall_risk, result.overall_severity.value)
        return result.to_dict()
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        log.error("Scan failed: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=f"Scan failed: {str(e)}")


# ── Alerts ───────────────────────────────────────────────────────────────────

@app.get("/api/alerts")
async def get_alerts(repo_id: str | None = None, limit: int = 50):
    return db.get_alerts(repo_id=repo_id, limit=limit)


@app.post("/api/alerts/{alert_id}/acknowledge")
async def acknowledge_alert(alert_id: str):
    db.acknowledge_alert(alert_id)
    return {"status": "acknowledged"}


# ── Scan history ─────────────────────────────────────────────────────────────

@app.get("/api/history")
async def get_history(limit: int = 20):
    """Returns all previously scanned repos — the history panel."""
    return db.get_scan_history(limit=limit)


# ── Demo ─────────────────────────────────────────────────────────────────────

@app.post("/api/demo/reset")
async def demo_reset():
    db.reset()
    return {"status": "reset complete"}


@app.post("/api/demo/run")
async def demo_run():
    """
    Automatically scans 3 real repos to populate the dashboard for demos.
    Uses repos that are known to have interesting histories.
    """
    demo_repos = [
        "https://github.com/torvalds/linux",
        "https://github.com/psf/requests",
        "https://github.com/django/django",
    ]
    results = []
    for url in demo_repos:
        try:
            result = await scanner.scan(url)
            db.save_scan(result)
            for alert in result.alerts:
                db.insert_alert(alert)
            results.append({"repo": result.repo_id, "risk": result.overall_risk, "severity": result.overall_severity.value})
        except Exception as e:
            results.append({"repo": url, "error": str(e)})
    return {"scanned": results}
