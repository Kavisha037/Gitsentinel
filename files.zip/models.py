from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Literal
from uuid import UUID, uuid4


class Severity(str, Enum):
    NONE = "none"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

    def score(self) -> int:
        return {"none": 0, "low": 15, "medium": 40, "high": 70, "critical": 100}[self.value]

    def color(self) -> str:
        return {
            "none": "#22c55e",
            "low": "#3b82f6",
            "medium": "#eab308",
            "high": "#f97316",
            "critical": "#ef4444",
        }[self.value]


@dataclass
class NormalizedEvent:
    platform: Literal["github", "gitlab", "gitea", "scan"]
    repo_id: str
    event_type: Literal["push", "member_added", "pr_merged", "ci_modified", "scan"]
    actor: str
    timestamp: datetime
    files_changed: list[str] = field(default_factory=list)
    payload: dict = field(default_factory=dict)

    def has_ci_files(self) -> bool:
        CI = [".github/workflows/", ".gitlab-ci.yml", "Jenkinsfile", ".circleci/", "Makefile"]
        return any(any(p in f for p in CI) for f in self.files_changed)

    def has_binary_files(self) -> bool:
        EXTS = {".exe", ".o", ".so", ".dll", ".bin", ".wasm", ".pyc", ".a"}
        return any(f.endswith(tuple(EXTS)) for f in self.files_changed)


@dataclass
class DetectionResult:
    severity: Severity
    detector_name: str
    reason: str
    recommendation: str
    confidence: float = 1.0

    def is_flagged(self) -> bool:
        return self.severity != Severity.NONE

    def to_dict(self) -> dict:
        return {
            "severity": self.severity.value,
            "detector_name": self.detector_name,
            "reason": self.reason,
            "recommendation": self.recommendation,
            "confidence": self.confidence,
        }


@dataclass
class ContributorBaseline:
    repo_id: str
    actor: str
    total_commits: int = 0
    avg_daily_commits: float = 0.0
    commit_stddev: float = 0.0
    typical_extensions: list[str] = field(default_factory=list)
    active_hours: list[int] = field(default_factory=list)
    days_of_data: int = 0
    last_updated: datetime = field(default_factory=datetime.utcnow)

    def is_trusted(self, min_commits: int = 10) -> bool:
        return self.total_commits >= min_commits

    def is_sufficient(self) -> bool:
        return self.days_of_data >= 14


@dataclass
class Alert:
    repo_id: str
    actor: str
    risk_score: int
    severity: Severity
    findings: list[DetectionResult]
    timestamp: datetime = field(default_factory=datetime.utcnow)
    id: UUID = field(default_factory=uuid4)
    acknowledged: bool = False

    def to_dict(self) -> dict:
        return {
            "id": str(self.id),
            "repo_id": self.repo_id,
            "actor": self.actor,
            "risk_score": self.risk_score,
            "severity": self.severity.value,
            "severity_color": self.severity.color(),
            "findings": [f.to_dict() for f in self.findings],
            "timestamp": self.timestamp.isoformat(),
            "acknowledged": self.acknowledged,
        }


@dataclass
class RepoScanResult:
    repo_url: str
    repo_id: str
    overall_risk: int
    overall_severity: Severity
    total_commits_scanned: int
    contributors_count: int
    alerts: list[Alert]
    scan_timestamp: datetime = field(default_factory=datetime.utcnow)
    stars: int = 0
    description: str = ""

    def to_dict(self) -> dict:
        return {
            "repo_url": self.repo_url,
            "repo_id": self.repo_id,
            "overall_risk": self.overall_risk,
            "overall_severity": self.overall_severity.value,
            "overall_severity_color": self.overall_severity.color(),
            "total_commits_scanned": self.total_commits_scanned,
            "contributors_count": self.contributors_count,
            "alerts": [a.to_dict() for a in self.alerts],
            "scan_timestamp": self.scan_timestamp.isoformat(),
            "stars": self.stars,
            "description": self.description,
        }
